package org.cdac;
public abstract class Employee implements Comparable<Employee>  {
	
	protected String name;
	protected String address;
	protected int age;
	protected String gender;
	protected float salary;

	@Override
    public int compareTo(Employee other) {
        return this.getName().compareTo(other.getName()); // A→Z by name
    }
	
	Employee() {

		name = "";
		address = "";
		age = 0;
		gender = "";
		salary = 0.0f;

	}

	public String getName() {
		return name;
	}

	public Employee(String name, String address, int age, String gender, float salary) {
		this.name = setName(name);
		this.address = setAddress(address);
		this.age = setAge(age);
		this.gender = setGender(gender);
		this.salary = setSalary(salary);
	}

	public String setName(String name) {
		if (name == null || name == "" || name.length() < 4) {
			return "NONE";
		}
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String setAddress(String address) {
		if (address == null || address == "") {
			return "NONE";
		}
		return address;
	}

	public int getAge() {
		return age;
	}

	public int setAge(int age){
	    
	    	if(age < 18 ) {
	    		age = 18;
	    	}
	  
		if (age > 85) {
			return 18;
		}
		return age;
	}

	public String getGender() {
		return gender;
	}

	public String setGender(String gender) {
		if (gender.equals("M") || gender.equals("m"))
			return "MALE";
		if (gender.equals("f") || gender.equals("F"))
			return "FEMALE";

		return "NOT DEFIND";
	}

	public float getSalary() {
		return salary;
	}

	public float setSalary(float salary) {
		if (salary < 0) {
			return 1000;
		}
		return salary;
	}
// sorting by bubble sort sortEmpDesending
	public static void sortEmpAsending(Employee[] emp, int count) { 

	    for (int i = 0; i < count - 1; i++) {

	        for (int j = 0; j < count - 1 - i; j++) {

	            if (emp[j].name.compareTo(emp[j + 1].name) > 0) {
	                Employee temp = emp[j];
	                emp[j] = emp[j + 1];
	                emp[j + 1] = temp;
	            }
	        }
	    }
	    System.out.println("Employee data in assending Order --> ");
	   
	}
	
	public static void sortEmpDesending(Employee[] emp, int count) { 

	    for (int i = 0; i < count - 1; i++) {

	        for (int j = 0; j < count - 1 - i; j++) {

	            if (emp[j].name.compareTo(emp[j + 1].name) < 0) {
	                Employee temp = emp[j];
	                emp[j] = emp[j + 1];
	                emp[j + 1] = temp;
	            }
	        }
	    }
	   System.out.println("Employee data in Descending Order --> ");
	   
	}

	public void display() {
		System.out.println("Name    -> " + name);
		System.out.println("Age     -> " + age);
		System.out.println("Address -> " + address);
		System.out.println("Gender  -> " + gender);
		System.out.println("Salary  -> " + salary);
	}
}