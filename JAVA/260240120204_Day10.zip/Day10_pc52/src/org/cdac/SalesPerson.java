package org.cdac;

public class SalesPerson extends Employee{
	private float Commission ;
	SalesPerson(){
		Commission = 0.0f;
	}
	public SalesPerson(String name, int age , String address , String gender, float salary , float Commission) {
		super(name, address, age, gender, salary );
		
		this.Commission =setCommission(Commission);
		
	}
	public float getCommission() {
		return Commission;
	}
	public float setCommission(float Commission) {
		if(Commission < 0)return 0.0f;
		
		return Commission;
	}
		
}
