package org.cdac;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.io.File;
import java.io.FileOutputStream;

import org.cdac.utils.LinkedList;

public class Program {

	public static void main(String[] args) {
		final int addEmployee = 1;
		final int displayAll = 2;
		final int sortCase = 3;
		final int Save = 4;
		final int loadFile = 5;
		final int exit = 7;
		int count = 0;
		int choice;
		LinkedList link = new LinkedList();
		
		ArrayList<Employee> lis = new ArrayList<>();
		lis.add(new Engineer("prajwal", 22, "warud", "m", 5000, 500));
		lis.add(new Manager("ruchika", 21, "amravati", "f", 10000, 1000));
		lis.add(new SalesPerson("shrikant", 25, "kirmada", "m", 15000, 1500));

		do {
			System.out.println("1. for add employee ");
			System.out.println("2. for display Employee");
			System.out.println("3. for Sorting employee ");
			System.out.println("4. for Save data ");
			System.out.println("5. for Loading data ");
			System.out.println("6. to add list Employee to Linklist"); // day 10 task
			System.out.println("7. for Exit ");
			System.out.println("Enter the choice:");

			choice = ConsoleInput.getInt();

			switch (choice) {
			case addEmployee:
				System.out.println("Enter the name ");
				String name = ConsoleInput.getString();

				System.out.println("Enter the age ");
				int age = ConsoleInput.getInt();

				System.out.println("Enter the address ");
				String address = ConsoleInput.getString();

				System.out.println("Enter the gender M-> Male , F -> Female  ");
				String gender = ConsoleInput.getString();

				System.out.println("Enter the Salary ");
				float salary = ConsoleInput.getFloat();

				System.out.println("Which type of Employee");
				System.out.println("1. Manager \n2. Sales Employee \n3. Engineer \n4. Exit");
				int subChoice = ConsoleInput.getInt();

				switch (subChoice) {

				case 1:
					System.out.println("Enter an hrn(rupee) "); 
					float hrn = ConsoleInput.getFloat();
					link.add(new Manager(name, age, address, gender, salary, hrn));
					count++;
					break;
				case 2:
					System.out.println("Enter an commission(rupee) ");
					float commission = ConsoleInput.getFloat();
					link.add(new SalesPerson(name, age, address, gender, salary, commission));
					count++;
					break;
				case 3:
					System.out.println("Enter an OverTime(ruppe) ");
					float overTime = ConsoleInput.getFloat();
					link.add(new Engineer(name, age, address, gender, salary, overTime));
					break;
				default:
					System.out.println("Returning to main menu...");
				}
				break;

			case displayAll:
				
				int subChoiceDisplay = 0;
				do {
					System.out.println("1. Display First Employee");
					System.out.println("2. Display Last Employee");
					System.out.println("3. Display All Employee");
					System.out.println("4. EXIT");
					Employee [] empDisplay  = new Employee[1];
					subChoiceDisplay = ConsoleInput.getInt();
					switch (subChoiceDisplay){
					case 1:
						empDisplay[0] = (Employee)link.getFirst(); 
						 displayAllEmployees(empDisplay , 1);
						break;
					case 2:
						empDisplay[0]= (Employee)link.getLast(); 
						 displayAllEmployees(empDisplay , 1);
						break;
					case 3:
						displayAllEmployees(link , count);
						break;
					case 4 :
						break;
					default:
						System.out.println("Enter a valid Choice");
						break;
					}
				}while (subChoiceDisplay != 4);
				break;

			case sortCase:
				int subChoiceSort = 0;
				do {
					System.out.println("1. Sort Ascending by name");
					System.out.println("2. Sort Descending by name");
					System.out.println("3. EXIT");
					subChoiceSort = ConsoleInput.getInt();
					Employee[] tempArray = new Employee[link.maxCount()]; // convert list to Employee array
					 ArrayList<Employee> tempList = new ArrayList<>();
					if (subChoiceSort == 1 || subChoiceSort == 2) { 
			            for (int i = 0; i < link.maxCount(); i++) {
			                tempArray[i] = (Employee) link.get(i);
			                tempList.add((Employee) link.get(i));
			            }
			            
					}

					switch (subChoiceSort) {
					case 1:
						Collections.sort(tempList); 
		                System.out.println("--- Sorted Ascending Using Collections Sort ---"); // day 10
		                displayAllEmployees(tempList.toArray(new Employee[0]), tempList.size());
						break;
					case 2:
						Employee.sortEmpDesending(tempArray, count);
						displayAllEmployees(tempArray, count);
						break;
					case 3:
						break;
					default:
						System.out.println("Enter a valid Choice");
					}
				}while (subChoiceSort != 3);
				break;

			case Save:
				saveToFile(link , count);
				break;
			case loadFile:
				count = loadFromFile(link);
				break;
				
			case 6 :
				lisToLink(lis , link);
				System.out.println("Data Loaded Succesfully");
				count += lis.size();
				break;

			case exit:
				System.out.println("Thank YOU!");
				break;

			default:
				System.out.println("Enter a valid Choice");
		} 
	}while (choice != 7);
	}

	public static void displayAllEmployees(LinkedList lis, int count) {
		for (int i = 0; i < count; i++) {
			System.out.println("Emp NO: " + (1 + i));
			Employee emp = (Employee) lis.get(i);
			
			
			if (emp instanceof Manager) {
				System.out.println("Type: Manager");
				Manager obj = (Manager) emp;
				obj.display();
				System.out.println("HRN: " + obj.getHrn());
			} else if (emp instanceof SalesPerson) {
				System.out.println("Type: Sales Person");
				SalesPerson obj = (SalesPerson) emp;
				obj.display();
				System.out.println("Commission: " + obj.getCommission());
			} else if (emp instanceof Engineer) {
				System.out.println("Type: Engineer");
				Engineer obj = (Engineer) emp;
				obj.display();
				System.out.println("Overtime: " + obj.getOverTime());
			}
			System.out.println("===========================");
		}
	}

	public static void displayAllEmployees(Employee[] emp, int count) {
		for (int i = 0; i < count; i++) {
			System.out.println("Emp NO  " + (1 + i));

			if (emp[i] instanceof Manager) {
				System.out.println("Its Manager --> ");
				Manager obj = (Manager) emp[i];
				emp[i].display();

				System.out.println("HRN is " + obj.getHrn());
				System.out.println("===========================");
			}
			if (emp[i] instanceof SalesPerson) {
				System.out.println("Its Sales Person -->  ");
				SalesPerson obj = (SalesPerson) emp[i];
				emp[i].display();

				System.out.println("Commission in ruppe " + obj.getCommission());
				System.out.println("===========================");
			}
			if (emp[i] instanceof Engineer) {
				System.out.println("Its Engineer --> ");
				Engineer obj = (Engineer) emp[i];
				emp[i].display();

				System.out.println("Overtime in ruppe  " + obj.getOverTime());
				System.out.println("===========================");
			}
		}
	}
	public static void saveToFile(LinkedList lis, int count) {
	    try {
	        FileOutputStream fout = new FileOutputStream("employees.txt");
	        for (int i = 0; i < count; i++) {
	            Employee emp = (Employee) lis.get(i);
	            String line = "";

	            if (emp instanceof Manager) {
	                Manager m = (Manager) emp;
	                line = "MANAGER " + m.getName() + " " + m.getAge() + " " + m.getAddress() + " " + m.getGender() + " " + m.getSalary() + " " + m.getHrn() + "\n";
	            } else if (emp instanceof SalesPerson) {
	                SalesPerson s = (SalesPerson) emp;
	                line = "SALESPERSON " + s.getName() + " " + s.getAge() + " " + s.getAddress() + " " + s.getGender() + " " + s.getSalary() + " " + s.getCommission() + "\n";
	            } else if (emp instanceof Engineer) {
	                Engineer e = (Engineer) emp;
	                line = "ENGINEER " + e.getName() + " " + e.getAge() + " " + e.getAddress() + " " + e.getGender() + " " + e.getSalary() + " " + e.getOverTime() + "\n";
	            }

	            fout.write(line.getBytes());
	        }
	        fout.close();
	        System.out.println("Saved!");
	    } catch (Exception e) {
	        System.out.println("Error: " + e.getMessage());
	    }
	}
	public static int loadFromFile(LinkedList lis) {
	    int count = 0;
	    try {
	        Scanner sc = new Scanner(new File("employees.txt"));
	        while (sc.hasNextLine()) {
	            String line = sc.nextLine();
	            Scanner lineScanner = new Scanner(line);

	            String type    = lineScanner.next();
	            String name    = lineScanner.next();
	            int    age     = lineScanner.nextInt();
	            String address = lineScanner.next();
	            String gender  = lineScanner.next();
	            float  salary  = lineScanner.nextFloat();
	            float  extra   = lineScanner.nextFloat();

	            if (type.equals("MANAGER"))         lis.add(new Manager(name, age, address, gender, salary, extra));
	            else if (type.equals("SALESPERSON")) lis.add(new SalesPerson(name, age, address, gender, salary, extra));
	            else if (type.equals("ENGINEER"))    lis.add(new Engineer(name, age, address, gender, salary, extra));

	            count++;
	            lineScanner.close();
	        }
	        sc.close();
	        System.out.println("Loaded! " + count + " employees");
	    } catch (Exception e) {
	        System.out.println("Error: " + e.getMessage());
	    }
	    return count;
	}
	
	public static void lisToLink(ArrayList<Employee> lis , LinkedList link) {
		for(Employee e : lis) {
			link.add(e);
		}
	}
	
}