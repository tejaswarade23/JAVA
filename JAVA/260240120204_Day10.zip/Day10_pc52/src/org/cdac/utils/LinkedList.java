package org.cdac.utils;
//code in day 6
class Node {
	Node next;
	Node prev;
	Object data;

	public Node(Object temp) {
		this.data = temp;
	}
}

public class LinkedList {
	Node start;
	Node end;
	Node current;
	int maxCount = 0;

	public void add(Object data) {
		Node tempNode = new Node(data);
		if (start == null) {
			start = end = current = tempNode;
		} else {
			end.next = tempNode;
			tempNode.prev = end;
			end = tempNode;
		}
		maxCount++;
	}

	public void delete(int index) {
		if (start == null || index > maxCount + 1) {
			return;
		}
		if (start == end) {
			start = end = current = null;
		} else if (index == 0) {
			start = start.next;
			start.prev = null;
		} else if (index == maxCount - 1) {
			end = end.prev;
			end.next = null;
		} else {
			Node tempNode = start;

			for (int i = 0; i < index; i++)
				tempNode = tempNode.next;

			tempNode.prev.next = tempNode.next;
			tempNode.next.prev = tempNode.prev;
		}
		maxCount--;
	}
public Object getFirst() {
	if(start == null)return null;
	
	return start.data;
}
public Object getLast() {
	if(end == null)return null;
	return end.data;
}
public Object get(int index) {
	Node temp = start;
	for(int i = 0 ; i < index ; i++) {
	     if(temp == null)return null;
	     temp = temp.next;
	}
	return temp.data;
}
public int maxCount() {
	return maxCount;
}
}
