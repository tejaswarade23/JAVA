package org.cdac;

public class ConsoleInput {
		static String getString() {
			try {
				byte[] input = new byte[100];
				int len = System.in.read(input);
				byte [] finalInput = new byte[len -2];
				System.arraycopy(input, 0 , finalInput, 0, len-2);
				String objString = new String(finalInput);
				return objString;
			}catch(Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		static int getInt() { 
			return Integer.parseInt(getString());
		}
		static float getFloat() {
			String s = getString();
			return Float.parseFloat(s);	
		}
}
