package org.cdac;

public class Manager extends Employee {
      float hrn = 0.0f;
      
      public Manager(String name , int age , String address ,String gender , float salary , float hrn) {
  		super(name , address  , age , gender , salary);
  		this.hrn = setHrn(hrn);
  	}

	public float getHrn() {
		return hrn;
	}

	public float setHrn(float hrn) {
		 if(hrn < 0) {
			 hrn = 0;
		 }
		return hrn;
	}
}
