package org.cdac;

public class Engineer extends Employee {
	float overTime ;

	public Engineer() {
		 overTime = 0.0f;;
	}

	public Engineer(String name, int age, String address, String gender, float salary ,float overTime) {
		super(name, address , age , gender  ,   salary );
		this.overTime = setOverTime(overTime);
	}

	public float getOverTime() {
		return overTime;
	}

	public float setOverTime(float overTime) {
		if(overTime < 0)return 0;
		return overTime;
	}

}
