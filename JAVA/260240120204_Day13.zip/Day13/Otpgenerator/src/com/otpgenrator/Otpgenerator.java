package com.otpgenrator;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

class OtpGeneratorLogic { 

    private final Queue<Integer> queue = new LinkedList<>();
    private final int MAX_CAPACITY = 100;
    private final int RESUME_THRESHOLD = 20;
    private boolean isPaused = false;

 
    public synchronized void produce() throws InterruptedException {
        Random rand = new Random();

        while (true) {
          
            while (queue.size() >= MAX_CAPACITY) {
                System.out.println("[Producer] Buffer Full (100). Pausing...");
                isPaused = true;
                wait();
            }

         
            int otp = 100000 + rand.nextInt(900000);
            queue.add(otp);
            System.out.println("[Producer] Created OTP: " + otp + " | Buffer Size: " + queue.size());

           
            notifyAll();
            
            Thread.sleep(50); 
        }
    }

  
    public synchronized void consume() throws InterruptedException {
        while (true) {
            
            while (queue.isEmpty()) {
                System.out.println("[Consumer] Buffer empty. Waiting...");
                wait();
            }

         
            int otp = queue.poll();
            System.out.println("[Consumer] Processed OTP: " + otp + " | Remaining: " + queue.size());

           
            if (isPaused && queue.size() <= RESUME_THRESHOLD) {
                System.out.println("[Consumer] Buffer hit 20. Waking up Producer...");
                isPaused = false;
                notifyAll();
            }

            Thread.sleep(150); 
        }
    }
}

public class Otpgenerator {
    public static void main(String[] args) {
        OtpGeneratorLogic logic = new OtpGeneratorLogic();

        Thread producerThread = new Thread(() -> {
            try {
                logic.produce();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        Thread consumerThread = new Thread(() -> {
            try {
                logic.consume();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        producerThread.start();
        consumerThread.start();
    }
}