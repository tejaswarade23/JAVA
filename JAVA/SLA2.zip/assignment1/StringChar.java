package assignment1;

import java.util.Scanner;
//String Q1 (Char at Index)
public class StringChar {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter a string: ");
        String str = sc.nextLine();
        
        System.out.print("Enter index to check: ");
        int index = sc.nextInt();

        if (index >= 0 && index < str.length()) {
            System.out.println("The character at position " + index + " is " + str.charAt(index));
        } else {
            System.out.println("Invalid index!");
        }
        sc.close();
    }
}