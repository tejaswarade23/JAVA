package assignment1;
import java.util.Scanner;
//String Q3 (Ends with)
public class StringEnd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter the main string: ");
        String str = sc.nextLine();
        System.out.print("Enter the suffix to check: ");
        String suffix = sc.nextLine();

        System.out.println("\"" + str + "\" ends with \"" + suffix + "\"? " + str.endsWith(suffix));
        sc.close();
    }
}