package assignment1;

import java.util.Scanner;
//Question6
public class EmployeeTask {
    double salary;
    int hoursPerDay;

    // Method 1: Takes salary and hours as parameters
    public void getInfo(double s, int h) {
        salary = s;
        hoursPerDay = h;
    }

    // Method 2: Adds $10 if salary < $500
    public void addSal() {
        if (salary < 500) {
            salary += 10;
        }
    }

    // Method 3: Adds $5 if work > 6 hours
    public void addWork() {
        if (hoursPerDay > 6) {
            salary += 5;
        }
    }

    public void printFinalSalary() {
        System.out.println("The final salary of the employee is: $" + salary);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EmployeeTask emp = new EmployeeTask();

        System.out.print("Enter Employee Salary: ");
        double inputSal = sc.nextDouble();

        System.out.print("Enter Hours of work per day: ");
        int inputHours = sc.nextInt();

        // 1. Initialize data
        emp.getInfo(inputSal, inputHours);
        
        // 2. Apply logic
        emp.addSal();
        emp.addWork();
        
        // 3. Output result
        emp.printFinalSalary();
        
        sc.close();
    }
}