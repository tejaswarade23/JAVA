package assignment1;
import java.util.Scanner;
//QuestionQ2
class Member {
    private String name, address, phone;
    private int age;
    private double salary;

    // Setters (Mutators)
    public void setName(String n) { name = n; }
    public void setAge(int a) { age = a; }
    public void setPhone(String p) { phone = p; }
    public void setAddress(String ad) { address = ad; }
    public void setSalary(double s) { salary = s; }

    // Getters (Accessors)
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
    public double getSalary() { return salary; }

    public void printSalary() {
        System.out.println("Salary: " + salary);
    }
}

class PrimeMembers extends Member {
    private int joiningYear;
    private double joiningFees;
    private boolean isActive;

    public void setPrimeDetails(int yr, double fee, boolean active) {
        joiningYear = yr;
        joiningFees = fee;
        isActive = active;
    }

    public void display() {
        System.out.println("\n--- Prime Member Details ---");
        System.out.println("Name: " + getName());
        System.out.println("Age: " + getAge());
        System.out.println("Phone: " + getPhone());
        System.out.println("Address: " + getAddress());
        printSalary();
        System.out.println("Joined: " + joiningYear);
        System.out.println("Fees: " + joiningFees);
        System.out.println("Active: " + isActive);
    }
}

public class MemberTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PrimeMembers pm = new PrimeMembers();

        System.out.print("Enter Name: "); pm.setName(sc.nextLine());
        System.out.print("Enter Address: "); pm.setAddress(sc.nextLine());
        System.out.print("Enter Phone: "); pm.setPhone(sc.nextLine());
        System.out.print("Enter Age: "); pm.setAge(sc.nextInt());
        System.out.print("Enter Salary: "); pm.setSalary(sc.nextDouble());
        
        pm.setPrimeDetails(2024, 100.0, true);
        pm.display();
    }
}