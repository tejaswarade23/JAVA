package assignment1;
//Question2
public class Triangle {
    double side1, side2, side3;

    // Constructor with parameters
    Triangle(double s1, double s2, double s3) {
        side1 = s1;
        side2 = s2;
        side3 = s3;
    }

    public void printResults() {
        double perimeter = side1 + side2 + side3;
        double s = perimeter / 2; // semi-perimeter
        double area = Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));

        System.out.println("Perimeter of Triangle: " + perimeter + " units");
        System.out.println("Area of Triangle: " + area + " sq units");
    }

    public static void main(String[] args) {
        Triangle myTriangle = new Triangle(3, 4, 5);
        myTriangle.printResults();
    }
}