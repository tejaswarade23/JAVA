package assignment1;

import java.util.Scanner;
//String Q5 (Replace)
public class StringReplace {
    public static void main(String[] args) {
        // Create a Scanner object to read input
        Scanner sc = new Scanner(System.in);

        // 1. Get the original sentence from the user
        System.out.println("Enter the original sentence:");
        String originalStr = sc.nextLine();

        // 2. Get the word to be replaced
        System.out.println("Enter the word you want to replace (e.g., fox):");
        String target = sc.next();

        // 3. Get the new word to put in its place
        System.out.println("Enter the replacement word (e.g., cat):");
        String replacement = sc.next();

        // Perform the replacement logic
        String newStr = originalStr.replace(target, replacement);

        // Display the results
        System.out.println("\n--- Output ---");
        System.out.println("Original String: " + originalStr);
        System.out.println("New String:      " + newStr);

        // Close the scanner to be neat
        sc.close();
    }
}