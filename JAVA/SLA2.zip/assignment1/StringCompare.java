package assignment1;

import java.util.Scanner;
//String Q2 (Lexicographical Compare)
public class StringCompare {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter String 1: ");
        String s1 = sc.nextLine();
        System.out.print("Enter String 2: ");
        String s2 = sc.nextLine();

        int result = s1.compareTo(s2);

        if (result < 0) {
            System.out.println("\"" + s1 + "\" is less than \"" + s2 + "\"");
        } else if (result > 0) {
            System.out.println("\"" + s1 + "\" is greater than \"" + s2 + "\"");
        } else {
            System.out.println("Both strings are equal.");
        }
    }
}