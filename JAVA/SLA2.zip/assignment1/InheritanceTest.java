package assignment1;
//QuestionQ1
class Parent {
    public void parentMethod() {
        System.out.println("This is parent class");
    }
}

class Child extends Parent {
    public void childMethod() {
        System.out.println("This is child class");
    }
}

public class InheritanceTest {
    public static void main(String[] args) {
        Parent p = new Parent();
        Child c = new Child();

        p.parentMethod(); // 1 - Parent method by Parent object
        c.childMethod();  // 2 - Child method by Child object
        c.parentMethod(); // 3 - Parent method by Child object (Inheritance)
    }
}