package assignment1;

import java.util.*;
//LinkedList Q2
public class UniqueLinkedList {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList<Integer> uniqueList = new LinkedList<>();

        System.out.println("Enter numbers. I will only save 10 unique ones:");
        
        while (uniqueList.size() < 10) {
            System.out.print("Current size (" + uniqueList.size() + "/10). Enter number: ");
            int num = sc.nextInt();
            
            if (!uniqueList.contains(num)) {
                uniqueList.add(num);
            } else {
                System.out.println("Number " + num + " is already in the list. Skipping...");
            }
        }

        System.out.println("\nFinal Unique List: " + uniqueList);
    }
}