package assignment1;

import java.util.Scanner;
//String Q4 (Alphabet Index)
public class AlphabetIndex {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a sample string (like 'The quick brown fox...'): ");
        String str = sc.nextLine().toLowerCase();

        String abc = "abcdefghijklmnopqrstuvwxyz";
        
        System.out.println("Letter | Index in your string");
        System.out.println("----------------------------");
        for (int i = 0; i < abc.length(); i++) {
            char letter = abc.charAt(i);
            int index = str.indexOf(letter);
            System.out.print(letter + ":" + (index == -1 ? "N/A" : index) + "  ");
            
            // Format output into rows of 10 for readability
            if ((i + 1) % 10 == 0) System.out.println();
        }
    }
}