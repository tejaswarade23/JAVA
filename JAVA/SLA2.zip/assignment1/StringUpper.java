package assignment1;
import java.util.Scanner;
//String Q6 (Uppercase)
public class StringUpper {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter string to convert to uppercase: ");
        String str = sc.nextLine();
        
        System.out.println("Original String: " + str);
        System.out.println("String in uppercase: " + str.toUpperCase());
        sc.close();
    }
}