package assignment1;

import java.util.Scanner;
//QuestionQ3
class RectangleShape {
    double length, breadth;

    // Constructor to initialize length and breadth
    RectangleShape(double l, double b) {
        length = l;
        breadth = b;
    }

    void printArea() {
        System.out.println("Area: " + (length * breadth));
    }

    void printPerimeter() {
        System.out.println("Perimeter: " + (2 * (length + breadth)));
    }
}

class Square extends RectangleShape {
    // Constructor for Square passing side to the parent constructor
    Square(double side) {
        super(side, side);
    }
}

public class ShapeTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input for Rectangle
        System.out.print("Enter length of Rectangle: ");
        double l = sc.nextDouble();
        System.out.print("Enter breadth of Rectangle: ");
        double b = sc.nextDouble();
        RectangleShape rect = new RectangleShape(l, b);

        // Input for Square
        System.out.print("Enter side of Square: ");
        double s = sc.nextDouble();
        Square sq = new Square(s);

        System.out.println("\n--- Rectangle Results ---");
        rect.printArea();
        rect.printPerimeter();

        System.out.println("\n--- Square Results ---");
        sq.printArea();
        sq.printPerimeter();
        
        sc.close();
    }
}