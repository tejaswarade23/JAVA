package assignment1;
//Question1
public class Student {
    String name;
    int roll_no;
    String phone_no;
    String address;

    public static void main(String[] args) {
        // Part a & b: Creating objects for Sam and John
        Student sam = new Student();
        sam.name = "Sam";
        sam.roll_no = 1;
        sam.phone_no = "9876543210";
        sam.address = "68D- WallsStreat";

        Student john = new Student();
        john.name = "John";
        john.roll_no = 2;
        john.phone_no = "1234567890";
        john.address = "26B- WallsStreat";

        // Printing details
        System.out.println("Details of " + sam.name + ": Roll: " + sam.roll_no + ", Phone: " + sam.phone_no + ", Address: " + sam.address);
        System.out.println("Details of " + john.name + ": Roll: " + john.roll_no + ", Phone: " + john.phone_no + ", Address: " + john.address);
    }
}
