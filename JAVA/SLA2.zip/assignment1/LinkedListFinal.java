package assignment1;

import java.util.*;
//LinkedList Q1
public class LinkedListFinal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList<Integer> list = new LinkedList<>();

        System.out.println("Please enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            list.add(sc.nextInt());
        }

        // a. Display
        System.out.println("\nFull List: " + list);

        // b, c, d, e. Stats
        int sum = 0;
        int max = list.get(0);
        int min = list.get(0);
        for (int n : list) {
            sum += n;
            if (n > max) max = n;
            if (n < min) min = n;
        }
        
        System.out.println("Highest: " + max);
        System.out.println("Lowest: " + min);
        System.out.println("Total Sum: " + sum);
        System.out.println("Average: " + (sum / 10.0));

        // f. Find Index
        System.out.print("\nEnter a number to find its first index: ");
        int searchNum = sc.nextInt();
        System.out.println("Index position: " + list.indexOf(searchNum));

        // g. Find Repetitions
        System.out.print("Enter a number to count its occurrences: ");
        int repeatNum = sc.nextInt();
        int count = 0;
        for (int n : list) { if (n == repeatNum) count++; }
        System.out.println("This number appears " + count + " times.");
    }
}