package assignment1;
//Question4
import java.util.Scanner;

public class Complex {
    double real, imag;

    Complex(double r, double i) {
        real = r;
        imag = i;
    }

    public static Complex add(Complex a, Complex b) {
        return new Complex(a.real + b.real, a.imag + b.imag);
    }

    public static Complex diff(Complex a, Complex b) {
        return new Complex(a.real - b.real, a.imag - b.imag);
    }

    public static Complex product(Complex a, Complex b) {
        double resReal = (a.real * b.real) - (a.imag * b.imag);
        double resImag = (a.real * b.imag) + (a.imag * b.real);
        return new Complex(resReal, resImag);
    }

    public void display() {
        System.out.println(real + " + " + imag + "i");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Real and Imaginary part for Number 1:");
        Complex c1 = new Complex(sc.nextDouble(), sc.nextDouble());

        System.out.println("Enter Real and Imaginary part for Number 2:");
        Complex c2 = new Complex(sc.nextDouble(), sc.nextDouble());

        System.out.print("Sum: "); Complex.add(c1, c2).display();
        System.out.print("Difference: "); Complex.diff(c1, c2).display();
        System.out.print("Product: "); Complex.product(c1, c2).display();
        
        sc.close();
    }
}