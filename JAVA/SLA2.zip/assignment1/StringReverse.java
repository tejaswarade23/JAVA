package assignment1;
import java.util.Scanner;
//String Q7 (Reverse String)
public class StringReverse {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter a string to reverse: ");
        String str = sc.nextLine();

        // Using StringBuilder to reverse the string
        String reversed = new StringBuilder(str).reverse().toString();

        System.out.println("The given string is: " + str);
        System.out.println("The string in reverse order is: " + reversed);
        sc.close();
    }
}