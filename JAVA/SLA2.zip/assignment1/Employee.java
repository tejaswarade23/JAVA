package assignment1;
//Question5
public class Employee {
    String name, address;
    int yearOfJoining;
    double salary;

    Employee(String n, int y, double s, String a) {
        name = n;
        yearOfJoining = y;
        salary = s;
        address = a;
    }

    public void printInfo() {
        // \t creates a tab space for column alignment
        System.out.println(name + "\t\t" + yearOfJoining + "\t\t\t" + address);
    }

    public static void main(String[] args) {
        Employee e1 = new Employee("Robert", 1994, 0, "64C- WallsStreat");
        Employee e2 = new Employee("Sam", 2000, 0, "68D- WallsStreat");
        Employee e3 = new Employee("John", 1999, 0, "26B- WallsStreat");

        System.out.println("Name\t\tYear of joining\t\tAddress");
        e1.printInfo();
        e2.printInfo();
        e3.printInfo();
    }
}