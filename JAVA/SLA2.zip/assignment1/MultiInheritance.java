package assignment1;
//QuestionQ4
class Shape {
    void showShape() { 
        System.out.println("This is shape"); 
    }
}

class RectangleClass extends Shape {
    void showRect() { 
        System.out.println("This is rectangular shape"); 
    }
}

class Circle extends Shape {
    void showCircle() { 
        System.out.println("This is circular shape"); 
    }
}

class SquareSub extends RectangleClass {
    void showSquare() { 
        System.out.println("Square is a rectangle"); 
    }
}

public class MultiInheritance {
    public static void main(String[] args) {
        // Creating the object of the lowest subclass
        SquareSub sq = new SquareSub();

        // 1. Call method of Shape class by object of Square class
        sq.showShape(); 

        // 2. Call method of Rectangle class by object of Square class
        sq.showRect();  
        
        // 3. Optional: Call its own method
        sq.showSquare();
    }
}