import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.time.LocalDate;

public class TransactionManager {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Transaction> transactions = new ArrayList<>();

        // Taking input for 5 objects
        for (int i = 1; i <= 2; i++) {
            System.out.println("Enter details for Transaction " + i + ":");
            System.out.print("ID (int): ");
            int id = sc.nextInt();
            System.out.print("Amount (float): ");
            float amount = sc.nextFloat();
            System.out.print("Status (true/false): ");
            boolean status = sc.nextBoolean();
            System.out.print("Arrears (true/false): ");
            boolean arrears = sc.nextBoolean();

            // Using current date for simplicity, or you could parse a string here
            transactions.add(new Transaction(id, LocalDate.now(), amount, status, arrears));
        }

        // 1. Lambda for txAmount > 5000
        System.out.println("\n--- Transactions > 5000 ---");
        transactions.stream()
                .filter(t -> t.txAmount > 5000)
                .forEach(System.out::println);

        // 2. Lambda for txStatus is false
        System.out.println("\n--- Transactions with False Status ---");
        transactions.stream()
                .filter(t -> !t.txStatus)
                .forEach(System.out::println);

        // 3. Lambda Function to generate Amount Due
        // Calculation: txAmount + 500 + (18% of txAmount) if arrears is true
        Function<Transaction, Double> calculateDue = t -> {
            if (t.txArrears) {
                return t.txAmount + 500 + (t.txAmount * 0.18);
            } else {
                return (double) t.txAmount;
            }
        };

        System.out.println("\n--- Calculated Amount Due for each Transaction ---");
        for (Transaction t : transactions) {
            double totalDue = calculateDue.apply(t);
            System.out.println("ID: " + t.txId + " | Final Amount Due: " + totalDue);
        }
    }
}