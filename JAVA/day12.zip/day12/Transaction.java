import java.time.LocalDate;

class Transaction {
    int txId;
    LocalDate txDate;

    float txAmount;
    boolean txStatus;
    boolean txArrears;

    public Transaction(int txId, LocalDate txDate, float txAmount, boolean txStatus, boolean txArrears) {
        this.txId = txId;
        this.txDate = txDate;
        this.txAmount = txAmount;
        this.txStatus = txStatus;
        this.txArrears = txArrears;
    }

    @Override
    public String toString() {
        return String.format("ID: %d | Date: %s | Amount: %.2f | Status: %b | Arrears: %b",
                txId, txDate, txAmount, txStatus, txArrears);
    }
}